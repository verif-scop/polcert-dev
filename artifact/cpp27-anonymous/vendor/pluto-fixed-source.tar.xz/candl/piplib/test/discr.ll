((un discriminant de Newpip)
()
)
