((variables : a b c d ...., pas de parametres)
(list #[ 2]
#[ 1]
#[ 1]
#[ 5]
#[ 19]
#[ 100]
#[ 617]
#[ 4410]
#[ 35840]
#[ 326592]
)
)
